class FingerprintDataset:
    pass
