if __name__=='__main__':
    print('Training placeholder')
